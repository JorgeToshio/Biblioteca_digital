package com.gestao.biblioteca.gestao_biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoBibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
